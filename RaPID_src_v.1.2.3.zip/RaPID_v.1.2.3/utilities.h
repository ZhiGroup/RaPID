/* Random Projection-based IBD Detection (RaPID)
 * Authors: Ardalan Naseri, Xiaoming Liu, Shaojie Zhang and Degui Zhi

 * RaPID is free for academic use. For commercial use, please contact authors.
 * RaPID is based on Richard Durbin's PBWT (richarddurbin/pbwt).

 *-------------------------------------------------------------------
 * utilities.h
 * auxiliary function(s) for Random Projection PBWT (RaPID)
 * Created on: Dec 7, 2017
 */

#ifndef UTILITIES_H_
#define UTILITIES_H_
#include <vector>
#include <string>
using namespace std;


static void tokenize_string(const string& str,
		vector<string>& tokens,
		const string& delimiters = " ")
{
	string::size_type lastPos = str.find_first_not_of(delimiters, 0);
	string::size_type pos = str.find_first_of(delimiters, lastPos);

	while (string::npos != pos || string::npos != lastPos)
	{
		tokens.push_back(str.substr(lastPos, pos - lastPos));
		lastPos = str.find_first_not_of(delimiters, pos);
		pos = str.find_first_of(delimiters, lastPos);
	}
}





#endif /* UTILITIES_H_ */
