/* Random Projection-based IBD Detection (RaPID)
 * Authors: Ardalan Naseri, Xiaoming Liu, Shaojie Zhang and Degui Zhi
 *
 *  RaPID is free for academic use. For commercial use, please contact authors.
 *  RaPID is based on Richard Durbin's PBWT (richarddurbin/pbwt).
 *
 *
 *-------------------------------------------------------------------
 * Merge.h
 * auxiliary functions for merging hits from different runs.
 * Created on: Dec 10, 2017
 */


#include "Merge.h"

Merge::Merge() {

}

Merge::~Merge() {
}



/***
 * Sort PBWT entries by the their first index.
 */
vector<Merge::PBWT_ENTRY> Merge::counting_sort_first_index(vector<Merge::PBWT_ENTRY> & entries,int max_number,int entries_length){


	int C[max_number+1];

	for (int i = 0;i < max_number+1;i++){
		C[i] =0;
	}

	for ( int j = 1; j < entries_length;j++){
		C[entries[j].index_1] +=1;
	}

	for (int m = 1; m <max_number+1; m++){
		C[m] += C[m-1];
	}
	vector<PBWT_ENTRY> n;
	n.resize(entries.size());

	for (int j= entries_length-1; j>=0 ;j--){

		n[C[entries[j].index_1]] = entries[j];
		C[entries[j].index_1] -=1;
	}
	return n;
}


/***
 * Sort PBWT entries by the their second index.
 */
vector<Merge::PBWT_ENTRY> Merge::counting_sort_second_index(vector<Merge::PBWT_ENTRY> & entries,int max_number){

	int C[max_number+1];

	for (int i = 0;i < max_number+1;i++){
		C[i] =0;
	}
	for (unsigned int j = 1; j < entries.size();j++){
		C[entries[j].index_2] +=1;
	}

	for (int m = 1; m <max_number+1; m++){
		C[m] += C[m-1];
	}

	vector<PBWT_ENTRY> n;

	n.resize(entries.size());

	for (int j= entries.size()-1; j>=0 ;j--){
		n[C[entries[j].index_2]] = entries[j];
		C[entries[j].index_2] -=1;
	}
	return n;
}

vector<Merge::PBWT_ENTRY> Merge::mergeIntervals(vector<Merge::PBWT_ENTRY> &hits) {

	vector<PBWT_ENTRY> stack;

	if (hits.empty())
		return stack;

	sort(hits.begin(), hits.end(),cmpByStartingPos);

	stack.push_back(hits[0]);

	for (size_t i = 1; i < hits.size(); i++) {

		PBWT_ENTRY top = stack.back();

		if (top.ending_position < hits[i].starting_pos) {
			stack.push_back(hits[i]);
		}

		else if (top.ending_position < hits[i].ending_position) {
			top.ending_position = hits[i].ending_position;
			stack.pop_back();
			stack.push_back(top);
		}
	}

	for (auto it = stack.begin(); it != stack.end(); ++it){
		it->length = it->ending_position - it->starting_pos +1;
	}
	return stack;
}


void Merge::write_PBWT_entry(vector<PBWT_ENTRY> & entries,int length,string output_file){

	gzFile output_f = gzopen(output_file.c_str(),"wb");

	for (int i =1; i <length;i ++){
		stringstream ss;
		ss << "MATCH";
		ss << "\t";
		ss << entries[i].index_1;
		ss << "\t";
		ss << entries[i].index_2;
		ss << "\t";
		ss << entries[i].starting_pos;
		ss << "\t";
		ss << entries[i].starting_pos+entries[i].length - 1;
		ss << "\t";
		ss << entries[i].length;
		ss << "\n";
		gzprintf(output_f,ss.str().c_str());
	}
	gzclose(output_f);
}


/***
 * Read PBWT results stored in a text file and store them in compresed format. The max num hits causes sorting in mulitle files and merge the results.
 */
void Merge::sort_store_compressed(string output_folder,string file_path,int pop_size,int max_num_hits, int &num_files){


	int counter = 0;

	ifstream input_vcf_file(file_path.c_str(), std::ios_base::in | std::ios_base::binary);
	boost::iostreams::filtering_streambuf<boost::iostreams::input> inbuf;
	inbuf.push(boost::iostreams::gzip_decompressor());
	inbuf.push(input_vcf_file);
	std::istream instream(&inbuf);

	string _line;
	vector<PBWT_ENTRY> values;

	values.push_back(PBWT_ENTRY(0,0,-1,-1));

	while(getline(instream,_line)){
		std::vector<std::string> strs;
		tokenize_string(_line,strs," \t");
		PBWT_ENTRY pbwt_entry;

		if (strs.size()<3) continue;
		int f_index = atoi(strs[1].c_str());
		int s_index = atoi(strs[2].c_str());
		if (f_index < s_index){
			pbwt_entry.index_1 = f_index;
			pbwt_entry.index_2 = s_index;
		}
		else{
			pbwt_entry.index_1 = s_index;
			pbwt_entry.index_2 = f_index;
		}
		pbwt_entry.starting_pos = atoi(strs[3].c_str());
		pbwt_entry.length = atoi(strs[4].c_str())-atoi(strs[3].c_str());
		values.push_back(pbwt_entry);
		counter++;

		if (counter > max_num_hits){
			vector<PBWT_ENTRY> sorted_entries = counting_sort_second_index(values,pop_size+1);
			vector<PBWT_ENTRY> sorted_ents = counting_sort_first_index(sorted_entries,pop_size+1,values.size());
			stringstream r_pbwt_output;
			r_pbwt_output << output_folder;
			r_pbwt_output << "/";
			r_pbwt_output << num_files;
			write_PBWT_entry(sorted_ents,values.size(),r_pbwt_output.str());
			values.clear();
			num_files++;
			counter= 0;
		}
	}

	if (counter > 0 ){

		vector<PBWT_ENTRY> sorted_entries = counting_sort_second_index(values,pop_size+1);
		vector<PBWT_ENTRY> sorted_ents = counting_sort_first_index(sorted_entries,pop_size+1,values.size());
		stringstream r_pbwt_output;
		r_pbwt_output << output_folder;
		r_pbwt_output << "/";
		r_pbwt_output << num_files;
		write_PBWT_entry(sorted_ents,values.size(),r_pbwt_output.str());
		values.clear();
		num_files++;
		counter= 0;
	}

	input_vcf_file.close();
	std::remove(file_path.c_str());

}

void Merge::merge_files(vector<string> file_names,string output_file,int win_size){


	gzFile output_gz = gzopen(output_file.c_str(),"wb");
	vector<istream*> input_files;
	vector<ifstream*> input_fff;
	vector<bool> end_files;
	vector<PBWT_ENTRY> curr_values;
	int ended_files = 0;

	for (unsigned int i= 0 ; i < file_names.size();i++){


		string file_path = file_names[i];
		ifstream *input_vcf_file = new ifstream();
		input_vcf_file->open(file_path.c_str(),std::ios_base::in | std::ios_base::binary);
		boost::iostreams::filtering_streambuf<boost::iostreams::input> * inbuf = new boost::iostreams::filtering_streambuf<boost::iostreams::input>() ;
		inbuf->push(boost::iostreams::gzip_decompressor());
		inbuf->push(*input_vcf_file);
		std::istream*  instream= new istream(inbuf);
		input_fff.push_back(input_vcf_file);
		input_files.push_back(instream);
		end_files.push_back(false);
		string sLine;
		getline(*instream, sLine);

		if (sLine != ""){
			curr_values.push_back(get_PBWT_ENTRY_object(sLine));
		}

		else{

			PBWT_ENTRY pbwt_entry;
			pbwt_entry.index_1 = std::numeric_limits<int>::max();
			pbwt_entry.index_2 = std::numeric_limits<int>::max();
			pbwt_entry.starting_pos = -1;
			pbwt_entry.length = -1;
			curr_values.push_back(pbwt_entry);
			ended_files++;
			end_files[i] = true;

		}
	}

	while (ended_files < file_names.size()){

		PBWT_ENTRY h_min = *min_element(curr_values.begin(),curr_values.end(),cmp);

		int h_min_first_indx = h_min.index_1;
		int h_min_second_indx = h_min.index_2;
		for (unsigned int j = 0 ; j < curr_values.size();j++){
			PBWT_ENTRY c_j;
			if (end_files[j] == false){
				c_j = curr_values[j];
				while (end_files[j] == false && c_j.index_1== h_min_first_indx && c_j.index_2 == h_min_second_indx){

					stringstream ss;
					ss << "MATCH\t";
					ss << c_j.index_1;
					ss << "\t";
					ss << c_j.index_2;
					ss << "\t";
					ss << c_j.starting_pos*win_size;
					ss << "\t";
					ss << c_j.ending_position*win_size - 1;
					ss << "\n";

					gzprintf(output_gz,ss.str().c_str());

					string sLine;

					getline(*input_files[j], sLine);
					if (sLine != ""){
						c_j = get_PBWT_ENTRY_object(sLine);
						curr_values[j] = c_j;
					}
					else{

						end_files[j] = true;
						ended_files++;

						PBWT_ENTRY pbwt_entry;
						pbwt_entry.index_1 = std::numeric_limits<int>::max();
						pbwt_entry.index_2 = std::numeric_limits<int>::max();
						pbwt_entry.starting_pos = -1;
						pbwt_entry.length = -1;
						curr_values[j] = pbwt_entry;
					}
				}
			}
		}

	}


	for (unsigned int i = 0 ; i <input_files.size() ; i++){
		input_fff[i]->close();
		delete input_fff[i];
		delete input_files[i];

		std::remove(file_names[i].c_str());

	}

	gzclose(output_gz);

}

void Merge::merge_files_support(vector<string> file_names,string output_file,int min_support){


	gzFile output_gz = gzopen(output_file.c_str(),"wb");
	vector<istream*> input_files;
	vector<ifstream*> input_fff;
	vector<bool> end_files;
	vector<PBWT_ENTRY> curr_values;
	int ended_files = 0;

	for (unsigned int i= 0 ; i < file_names.size();i++){

		string file_path = file_names[i];
		ifstream *input_vcf_file = new ifstream();
		input_vcf_file->open(file_path.c_str(),std::ios_base::in | std::ios_base::binary);
		boost::iostreams::filtering_streambuf<boost::iostreams::input> * inbuf = new boost::iostreams::filtering_streambuf<boost::iostreams::input>() ;
		inbuf->push(boost::iostreams::gzip_decompressor());
		inbuf->push(*input_vcf_file);
		std::istream*  instream= new istream(inbuf);
		input_fff.push_back(input_vcf_file);
		input_files.push_back(instream);
		end_files.push_back(false);
		string sLine;
		getline(*instream, sLine);

		if (sLine != ""){
			curr_values.push_back(get_PBWT_ENTRY_object(sLine));
		}
		else{

			PBWT_ENTRY pbwt_entry;
			pbwt_entry.index_1 = std::numeric_limits<int>::max();
			pbwt_entry.index_2 = std::numeric_limits<int>::max();
			pbwt_entry.starting_pos = -1;
			pbwt_entry.length = -1;
			curr_values.push_back(pbwt_entry);
			ended_files++;
			end_files[i] = true;

		}
	}

	while (ended_files < file_names.size()){

		vector<Interval<PBWT_ENTRY> >  temp_intervals;

		PBWT_ENTRY h_min = *min_element(curr_values.begin(),curr_values.end(),cmp);

		int h_min_first_indx = h_min.index_1;
		int h_min_second_indx = h_min.index_2;
		for (unsigned int j = 0 ; j < curr_values.size();j++){
			PBWT_ENTRY c_j;
			if (end_files[j] == false){
				c_j = curr_values[j];
				while (end_files[j] == false && c_j.index_1== h_min_first_indx && c_j.index_2 == h_min_second_indx){
					temp_intervals.push_back(Interval<PBWT_ENTRY>(c_j.starting_pos,c_j.starting_pos+c_j.length,c_j));
					string sLine;
					getline(*input_files[j], sLine);
					if (sLine != ""){
						c_j = get_PBWT_ENTRY_object(sLine);
						curr_values[j] = c_j;
					}
					else{

						end_files[j] = true;
						ended_files++;

						PBWT_ENTRY pbwt_entry;
						pbwt_entry.index_1 = std::numeric_limits<int>::max();
						pbwt_entry.index_2 = std::numeric_limits<int>::max();
						pbwt_entry.starting_pos = -1;
						pbwt_entry.length = -1;
						curr_values[j] = pbwt_entry;
					}
				}

			}
		}

		if (temp_intervals.size() >= min_support){
			IntervalTree<PBWT_ENTRY> tree;
			vector<PBWT_ENTRY> passed_intervals;
			tree = IntervalTree<PBWT_ENTRY>(temp_intervals);
			for (size_t i = 0; i < temp_intervals.size();i++){
				vector<Interval<PBWT_ENTRY> > results;
				tree.findOverlapping(temp_intervals[i].start, temp_intervals[i].stop, results);
				if (results.size() >= min_support){
					passed_intervals.push_back(temp_intervals[i].value);
				}
			}

			vector<PBWT_ENTRY> passed_interval_merged = mergeIntervals(passed_intervals);
			for (unsigned int k = 0; k < passed_interval_merged.size() ; k++){
				int _starting_indx = passed_interval_merged[k].starting_pos ;
				int _ending_indx =  passed_interval_merged[k].ending_position ;
				stringstream ss;
				ss << "MATCH\t";
				ss << passed_interval_merged[k].index_1;
				ss << "\t";
				ss << passed_interval_merged[k].index_2;
				ss << "\t";
				ss << _starting_indx;
				ss << "\t";
				ss << _ending_indx;
				ss << "\t";
				ss << _ending_indx - _starting_indx+1;
				ss << "\n";

				gzprintf(output_gz,ss.str().c_str());


			}
		}
	}

	for (unsigned int i = 0 ; i <input_files.size() ; i++){
		input_fff[i]->close();
		delete input_fff[i];
		delete input_files[i];

		std::remove(file_names[i].c_str()); // delete file
	}
	gzclose(output_gz);
}

