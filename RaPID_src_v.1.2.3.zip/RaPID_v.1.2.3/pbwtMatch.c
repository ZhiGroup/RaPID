/*
 * Random Projection-based IBD Detection (RaPID)
 * Authors: Ardalan Naseri, Xiaoming Liu, Shaojie Zhang and Degui Zhi

 * RaPID is free for academic use. For commercial use, please contact authors.
 * RaPID is based on Richard Durbin's PBWT (richarddurbin/pbwt).

 *-------------------------------------------------------------------
 * pbwtMatch.c
 * Searches a panel and outputs all matches greater than a given length.
 * This file had its origins as part of the PBWT, written by
 * Richard Durbin (MRC LMB, UK) rd@mrc-lmba.cam.ac.uk,
 * Created on: Oct 18, 2016
 *-------------------------------------------------------------------
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *   http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *-------------------------------------------------------------------
 */



#include "pbwt.h"



static void matchLongWithin (PBWT *p, int T,double gl,double* genetic_maps,int w,char* output_file)
{
	int i, i0 = 0, ia, ib, na = 0, nb = 0, dmin, k ;
	PbwtCursor *u = pbwtCursorCreate (p, TRUE, TRUE) ;
	gzFile fp = gzopen(output_file,"wb");

	for (k = 0 ; k <= p->N ; ++k){

		for (i = 0 ; i < u->M ; ++i)
		{ if ( (u->d[i] > k-T))
		{
			if ((na && nb) || k==p->N -1 )		/* then there is something to report */

				for (ia = i0 ; ia < i ; ++ia)

					for (ib = ia+1, dmin = 0 ; ib < i ; ++ib)
					{ if (u->d[ib] > dmin) dmin = u->d[ib] ;
					if (u->y[ib] != u->y[ia]){
						if (genetic_maps[(k+1)*w-1]-genetic_maps[dmin*w]> gl)
							gzprintf(fp,"MATCH\t%d\t%d\t%d\t%d\n",u->a[ia], u->a[ib], dmin, k);
					}
					else if (k==p->N -1){

						if (genetic_maps[p->N-1]-genetic_maps[dmin*w]> gl)
							gzprintf(fp,"MATCH\t%d\t%d\t%d\t%d\n",u->a[ia], u->a[ib], dmin, k+1);


					}

					}


			na = 0 ; nb = 0 ; i0 = i ;
		}
		if (u->y[i] == 0)
			na++ ;
		else
			nb++ ;

		}

		pbwtCursorForwardsReadAD (u, k) ;
	}

	gzclose(fp);
	pbwtCursorDestroy (u) ;
}


static void matchLongWithin_no_gl (PBWT *p, int T,char* output_file)
{
	int i, i0 = 0, ia, ib, na = 0, nb = 0, dmin, k ;
	PbwtCursor *u = pbwtCursorCreate (p, TRUE, TRUE) ;
	gzFile fp = gzopen(output_file,"wb");

	for (k = 0 ; k <= p->N ; ++k){

		for (i = 0 ; i < u->M ; ++i)
		{ if (u->d[i] > k-T)
		{
			if ((na && nb) || k==p->N -1 )		/* then there is something to report */
			{

				for (ia = i0 ; ia < i ; ++ia)
				{
					for (ib = ia+1, dmin = 0 ; ib < i ; ++ib)
					{ if (u->d[ib] > dmin) dmin = u->d[ib] ;
					if (u->y[ib] != u->y[ia] || k==p->N -1){
						gzprintf(fp ,"MATCH\t%d\t%d\t%d\t%d\n",u->a[ia], u->a[ib], dmin, k);

					}
					}
				}
			}
			na = 0 ; nb = 0 ; i0 = i ;
		}
		if (u->y[i] == 0)
			na++ ;
		else
			nb++ ;

		}

		pbwtCursorForwardsReadAD (u, k) ;
	}

	gzclose(fp);
	pbwtCursorDestroy (u) ;
}



void pbwtLongMatches (PBWT *p, int L, double gl,double* genetic_maps, int w,const char* out_put_file) /* reporting threshold L - if 0 then maximal */
{

	matchLongWithin(p, L,gl,genetic_maps,w,out_put_file);

}

void pbwtLongMatches_no_gl (PBWT *p, int L,const char* out_put_file) /* reporting threshold L - if 0 then maximal */
{

	matchLongWithin_no_gl(p, L,out_put_file);

}

