/* Random Projection-based IBD Detection (RaPID)
 * Authors: Ardalan Naseri, Xiaoming Liu, Shaojie Zhang and Degui Zhi

 * RaPID is free for academic use. For commercial use, please contact authors.
 * RaPID is based on Richard Durbin's PBWT (richarddurbin/pbwt).

 *-------------------------------------------------------------------
 * RaPID.cpp
 * functions and main method for Random Projection PBWT (RaPID)
 * Created on: Oct 18, 2016
 * Revised on June 22, 2017
 */

#include "IntervalTree.h"
#include <iostream>
#include <fstream>
#include "PBWTEntry.h"
#include <sstream>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <random>
#include <time.h>
#include "Merge.h"

extern "C"
{
#include "pbwt.h"
}



using namespace std;

// round result
double round(double d) {
	return floor(d + 0.5);
}

bool cmpByStartingPosReverse(const PBWT_ENTRY& lhs,const PBWT_ENTRY& rhs)
{
	return lhs.starting_pos > rhs.starting_pos;
};


vector<vector <PBWT_ENTRY> > get_disjoint_sets(vector<PBWT_ENTRY>& hits) {

	vector<vector <PBWT_ENTRY> > res;
	vector<PBWT_ENTRY> stack;

	if (hits.empty())
		return res;

	sort(hits.begin(), hits.end(), cmpByStartingPos);
	stack.push_back(hits[0]);
	vector<PBWT_ENTRY> first_set;
	first_set.push_back(hits[0]);
	res.push_back(first_set);
	int ds_id = 0;

	for (size_t i = 1; i < hits.size(); i++) {

		PBWT_ENTRY top = stack.back();

		if (top.ending_position < hits[i].starting_pos) {
			stack.push_back(hits[i]);
			ds_id++;
			vector<PBWT_ENTRY> next_set;
			next_set.push_back(hits[i]);
			res.push_back(next_set);

		}

		else if (top.ending_position < hits[i].ending_position) {
			top.ending_position = hits[i].ending_position;
			stack.pop_back();
			stack.push_back(top);
			res[ds_id].push_back(hits[i]);


		}
	}

	return res;
}



bool cmpByEndingPosReverse(const PBWT_ENTRY& lhs,const PBWT_ENTRY& rhs)
{
	return lhs.starting_pos+lhs.length > rhs.starting_pos+rhs.length;
};



/***
 * Applies PBWT on the given input_macs_file.
 */
void run_PBWT(string input_macs_file,string pbwt_path,int min_length, float min_gen_length,double* genetic_maps,int w,
		string output_folder){

	std::string base_filename = input_macs_file.substr(input_macs_file.find_last_of("/\\") + 1);
	pbwtInit();
	FILE *fp ;
	PBWT *p = 0 ;
	if (p) pbwtDestroy (p);
	fp = fopen(input_macs_file.c_str(),"r");
	p = pbwtReadMacs(fp);
	string output_max =	output_folder +"/"+base_filename+".max";
	pbwtLongMatches(p,min_length,min_gen_length,genetic_maps,w,output_max.c_str());
	fclose(fp);

}



/***
 * Applies PBWT on the given input_macs_file.
 */
void run_PBWT(string input_macs_file,string pbwt_path,int min_length,
		string output_folder){

	std::string base_filename = input_macs_file.substr(input_macs_file.find_last_of("/\\") + 1);
	pbwtInit();
	FILE *fp ;
	PBWT *p = 0 ;
	if (p) pbwtDestroy (p);
	fp = fopen(input_macs_file.c_str(),"r");
	p = pbwtReadMacs(fp);
	fclose(fp);
	string output_max =	output_folder +"/"+base_filename+".max";
	pbwtLongMatches_no_gl(p,min_length,output_max.c_str());

}


vector<PBWT_ENTRY> mergeIntervals(vector<PBWT_ENTRY>& hits) {

	vector<PBWT_ENTRY> stack;

	if (hits.empty())
		return stack;

	sort(hits.begin(), hits.end(), cmpByStartingPos);

	stack.push_back(hits[0]);

	for (size_t i = 1; i < hits.size(); i++) {

		PBWT_ENTRY top = stack.back();

		if (top.ending_position < hits[i].starting_pos) {
			stack.push_back(hits[i]);
		}

		else if (top.ending_position < hits[i].ending_position) {
			top.ending_position = hits[i].ending_position;
			stack.pop_back();
			stack.push_back(top);
		}
	}

	for (auto it = stack.begin(); it != stack.end(); ++it){
		it->length = it->ending_position - it->starting_pos +1;
	}
	return stack;
}



/***
 * Compute the minor allele frequencies of the panel.
 */
vector<int> compute_MAF(string macs_filepath,int &num_sites,int &population_size){

	vector<int> mafs;
	ifstream input_macs_file;
	input_macs_file.open(macs_filepath.c_str());
	num_sites = 0;
	string _line;

	while(getline(input_macs_file,_line)){
		int num_ones = 0;
		int num_zeros = 0;
		std::vector<std::string> strs;
		strs = split(_line,'\t');
		if (strs[0] == "SITE:"){
			population_size = 0;
			num_sites++;
			string values = strs[4];
			for (unsigned int i =0; i < values.size(); i++){
				population_size++;
				if (values[i] == '1'){
					num_ones++;
				}
				else if (values[i] == '0'){
					num_zeros++;
				}
			}
			if (num_ones > num_zeros){
				mafs.push_back(num_zeros);
			}
			else{
				mafs.push_back(num_ones);

			}
		}
	}
	input_macs_file.close();
	return mafs;
}



static void get_n_sites_slow(string macs_filepath,int &num_sites){

	vector<int> mafs;
	ifstream input_macs_file;
	input_macs_file.open(macs_filepath.c_str());
	num_sites = 0;
	string _line;

	while(getline(input_macs_file,_line)){
		std::vector<std::string> strs;
		strs = split(_line,'\t');
		if (strs[0] == "SITE:"){
			num_sites++;
		}
	}
	input_macs_file.close();
}

/***
 * Generates the sum-samples of the panel (in macs file) based on the given window size.
 */
int generate_subsamples(string macs_file,int window_size,int num_runs, string output_folder,int &pop_size,int num_sites)
{

	const char* path = output_folder.c_str();

	createDir(path);

	int t = num_sites / window_size;
	int reminder_starting_index = t * window_size;
	int reminder = num_sites -reminder_starting_index;
	int i = 0;
	int site_counter = 0;
	vector<int> mafs = compute_MAF(macs_file,num_sites,pop_size);

	vector<int> R;
	R.resize(num_runs);
	ifstream input_macs_file;
	input_macs_file.open(macs_file.c_str());
	vector<ofstream*> output_files;
	for (int i = 0; i < num_runs; i++){
		ofstream* output_file = new ofstream();
		string output_path = "";
		ostringstream oss;
		oss << output_folder << "/" << "macs_subsample_" << i;
		output_path = oss.str();
		output_file->open(output_path.c_str());
		output_files.push_back(output_file);
	}
	string sLine;
	while (getline(input_macs_file,sLine)){
		std::vector<std::string> strs;
		strs = split(sLine,'\t');
		if (strs[0] == "SITE:"){
			pop_size =strs[4].size();
			if (site_counter% window_size == 0){
				i = 0;
				vector<double> choice_weight;
				choice_weight.resize(window_size);
				for (t = 0 ; t < window_size; t++){
					if (site_counter +t  >= num_sites){
						window_size = reminder; //changed!!
						break;
					}
				}
				int k = 0;
				while (k < num_runs ){ // bug fixed!

					std::mt19937 rng;
					rng.seed(std::random_device()());

					int proj = 0;
					if (window_size > 1){
						proj = rand() % (window_size-1);

					}
					R[k] = proj;
					k++;

				}
			}
			for (int j = 0 ; j < num_runs;j++){
				int r = R[j];
				if (r == i){
					*output_files[j] << strs[0];
					*output_files[j] << "\t";
					*output_files[j] << strs[1];
					*output_files[j] << "\t";
					*output_files[j] << strs[2];
					*output_files[j] << "\t";
					*output_files[j] << strs[3];
					*output_files[j] << "\t";
					*output_files[j] << strs[4];
					*output_files[j] << "\n";
				}
			}
			i++;
			site_counter++;

		}
		else if (strs[0] != "NEWICK_TREE:"){
			for (int j = 0; j < num_runs;j++){
				*output_files[j] <<sLine<< "\n";
			}
		}
	}
	input_macs_file.close();
	for (unsigned int i = 0 ; i <output_files.size() ; i++){
		output_files[i]->close();
		delete output_files[i];
	}
	return num_sites;

}


/***
 *Generates the sub-samples with a weighted probabilities to MAFs.
 */
int generate_subsamples_maf(string macs_file,int window_size,int num_runs, string output_folder,int &pop_size,int num_sites)
{

	const char* path = output_folder.c_str();

	createDir(path);

	int t = num_sites / window_size;
	int reminder_starting_index = t * window_size;
	int reminder = num_sites -reminder_starting_index;
	int i = 0;
	int site_counter = 0;
	vector<int> mafs = compute_MAF(macs_file,num_sites,pop_size);

	vector<int> R;
	R.resize(num_runs);
	ifstream input_macs_file;
	input_macs_file.open(macs_file.c_str());
	vector<ofstream*> output_files;
	for (int i = 0; i < num_runs; i++){
		ofstream* output_file = new ofstream();
		string output_path = "";
		ostringstream oss;
		oss << output_folder << "/" << "macs_subsample_" << i;
		output_path = oss.str();
		output_file->open(output_path.c_str());
		output_files.push_back(output_file);
	}
	string sLine;
	while (getline(input_macs_file,sLine)){
		std::vector<std::string> strs;
		strs = split(sLine,'\t');
		if (strs[0] == "SITE:"){
			pop_size =strs[4].size();
			if (site_counter% window_size == 0){
				i = 0;
				vector<double> choice_weight;
				choice_weight.resize(window_size);
				for (t = 0 ; t < window_size; t++){
					if (site_counter +t  >= num_sites){
						window_size = reminder; //changed!!
						break;
					}
					choice_weight[t] = mafs[site_counter+t];

				}
				int k = 0;
				while (k < num_runs ){

					std::mt19937 rng;
					rng.seed(std::random_device()());
					double sum_of_weight = 0;
					for(int m=0; m<window_size; m++) {
						sum_of_weight += choice_weight[m];
					}
					int rnd = ((double)random()/RAND_MAX ) *sum_of_weight;
					for(int l=0; l<window_size; l++) {
						if(rnd < choice_weight[l]){
							rnd = l;
							break;
						}
						rnd -= choice_weight[l];
					}
					choice_weight.clear();
					int proj = rnd;
					R[k] = proj;
					k++;
				}
			}
			for (int j = 0 ; j < num_runs;j++){
				int r = R[j];
				if (r == i){
					*output_files[j] << strs[0];
					*output_files[j] << "\t";
					*output_files[j] << strs[1];
					*output_files[j] << "\t";
					*output_files[j] << strs[2];
					*output_files[j] << "\t";
					*output_files[j] << strs[3];
					*output_files[j] << "\t";
					*output_files[j] << strs[4];
					*output_files[j] << "\n";
				}
			}
			i++;
			site_counter++;

		}
		else if (strs[0] != "NEWICK_TREE:"){
			for (int j = 0; j < num_runs;j++){
				*output_files[j] <<sLine<< "\n";
			}
		}
	}
	input_macs_file.close();
	for (unsigned int i = 0 ; i <output_files.size() ; i++){
		output_files[i]->close();
		delete output_files[i];
	}
	return num_sites;

}


/***
 * Merges multiple PBWT outputs based on the given min_support.
 *
 */
void merge_hits(vector<string> file_names,string output_file,int win_size,int total_v_s,unsigned int min_support,int min_size){

	vector<ifstream*> input_files;
	vector<bool> end_files;
	vector<PBWT_ENTRY> curr_values;
	int ended_files = 0;
	ofstream output_f;
	output_f.open(output_file.c_str());


	output_f << "MATCH\tHAP1_INDEX\tHAP2_INDEX\tSTARTING_POS\tENDING_POS\tLENGTH\n";
	for (unsigned int i= 0 ; i < file_names.size();i++){

		ifstream* _file = new ifstream();
		_file->open(file_names[i].c_str());
		input_files.push_back(_file);
		end_files.push_back(false);
		string sLine;
		getline(*_file, sLine);

		if (sLine != ""){
			curr_values.push_back(get_PBWT_ENTRY_object(sLine));
		}
		else{

			PBWT_ENTRY pbwt_entry;
			pbwt_entry.index_1 = std::numeric_limits<int>::max();
			pbwt_entry.index_2 = std::numeric_limits<int>::max();
			pbwt_entry.starting_pos = -1;
			pbwt_entry.length = -1;
			curr_values.push_back(pbwt_entry);
			ended_files++;
			end_files[i] = true;

		}
	}
	while (ended_files < file_names.size()){
		vector<Interval<PBWT_ENTRY>> temp_intervals;

		PBWT_ENTRY h_min = *min_element(curr_values.begin(),curr_values.end(),cmp);

		int h_min_first_indx = h_min.index_1;
		int h_min_second_indx = h_min.index_2;
		for (unsigned int j = 0 ; j < curr_values.size();j++){
			PBWT_ENTRY c_j;
			if (end_files[j] == false){
				c_j = curr_values[j];
				while (end_files[j] == false && c_j.index_1== h_min_first_indx && c_j.index_2 == h_min_second_indx){
					temp_intervals.push_back(Interval<PBWT_ENTRY>(c_j.starting_pos,c_j.starting_pos+c_j.length,c_j));
					string sLine;
					getline(*input_files[j], sLine);
					if (sLine != ""){
						c_j = get_PBWT_ENTRY_object(sLine);
						curr_values[j] = c_j;
					}
					else{

						end_files[j] = true;
						ended_files++;

						PBWT_ENTRY pbwt_entry;
						pbwt_entry.index_1 = std::numeric_limits<int>::max();
						pbwt_entry.index_2 = std::numeric_limits<int>::max();
						pbwt_entry.starting_pos = -1;
						pbwt_entry.length = -1;
						curr_values[j] = pbwt_entry;
					}
				}
			}
		}
		if (temp_intervals.size() >= min_support){
			IntervalTree<PBWT_ENTRY> tree;
			vector<PBWT_ENTRY> passed_intervals;
			tree = IntervalTree<PBWT_ENTRY>(temp_intervals);
			for (size_t i = 0; i < temp_intervals.size();i++){
				vector<Interval<PBWT_ENTRY> > results;
				tree.findOverlapping(temp_intervals[i].start, temp_intervals[i].stop, results);
				if (results.size() >= min_support){
					passed_intervals.push_back(temp_intervals[i].value);
				}
			}

			vector<PBWT_ENTRY> passed_interval_merged = mergeIntervals(passed_intervals);
			for (unsigned int k = 0; k < passed_interval_merged.size() ; k++){
				int _starting_indx = passed_interval_merged[k].starting_pos * win_size;
				int _ending_indx = (passed_interval_merged[k].starting_pos+passed_interval_merged[k].length)*win_size + win_size-1;
				if (_ending_indx > total_v_s){
					_ending_indx = total_v_s;
				}
				output_f << "MATCH\t";
				output_f << passed_interval_merged[k].index_1;
				output_f << "\t";
				output_f << passed_interval_merged[k].index_2;
				output_f << "\t";
				output_f << _starting_indx;
				output_f << "\t";
				output_f << _ending_indx;
				output_f << "\t";
				output_f << _ending_indx - _starting_indx+1;
				output_f << "\n";
			}
		}
	}


	for (unsigned int i = 0 ; i <input_files.size() ; i++){
		input_files[i]->close();
		delete input_files[i];

		std::remove(file_names[i].c_str()); // delete file

	}

	output_f.close();

}

/***
 * Sort PBWT entries by the their first index.
 */
vector<PBWT_ENTRY> counting_sort_first_index(vector<PBWT_ENTRY> & entries,int max_number,int entries_length){


	int C[max_number+1];

	for (int i = 0;i < max_number+1;i++){
		C[i] =0;
	}

	for ( int j = 1; j < entries_length;j++){
		C[entries[j].index_1] +=1;
	}

	for (int m = 1; m <max_number+1; m++){
		C[m] += C[m-1];
	}
	vector<PBWT_ENTRY> n;
	n.resize(entries.size());

	for (int j= entries_length-1; j>=0 ;j--){

		n[C[entries[j].index_1]] = entries[j];
		C[entries[j].index_1] -=1;
	}
	return n;
}


/***
 * Sort PBWT entries by the their second index.
 */
vector<PBWT_ENTRY> counting_sort_second_index(vector<PBWT_ENTRY> & entries,int max_number){

	int C[max_number+1];

	for (int i = 0;i < max_number+1;i++){
		C[i] =0;
	}
	for (unsigned int j = 1; j < entries.size();j++){
		C[entries[j].index_2] +=1;
	}

	for (int m = 1; m <max_number+1; m++){
		C[m] += C[m-1];
	}

	vector<PBWT_ENTRY> n;

	n.resize(entries.size());

	for (int j= entries.size()-1; j>=0 ;j--){
		n[C[entries[j].index_2]] = entries[j];
		C[entries[j].index_2] -=1;
	}
	return n;
}

/***
 * Read PBWT results stored in a text file and store them as PBWT objects.
 */
vector<PBWT_ENTRY> getPBWTResults(const char* file_path){

	ifstream file(file_path);
	string _line;
	vector<PBWT_ENTRY> values;
	while(getline(file,_line)){
		std::vector<std::string> strs;
		strs = split(_line,'\t');
		PBWT_ENTRY pbwt_entry;
		if (strs.size()<3) continue;
		int f_index = atoi(strs[1].c_str());
		int s_index = atoi(strs[2].c_str());
		if (f_index < s_index){
			pbwt_entry.index_1 = f_index;
			pbwt_entry.index_2 = s_index;
		}
		else{
			pbwt_entry.index_1 = s_index;
			pbwt_entry.index_2 = f_index;
		}
		pbwt_entry.starting_pos = atoi(strs[3].c_str());
		pbwt_entry.length = atoi(strs[4].c_str())-atoi(strs[3].c_str());
		values.push_back(pbwt_entry);
	}
	return values;
}

void write_PBWT_entry(vector<PBWT_ENTRY> & entries,int length,string output_file){

	ofstream output_f;
	output_f.open(output_file.c_str());

	for (int i =1; i <length;i ++){
		output_f << "MATCH";
		output_f << "\t";
		output_f << entries[i].index_1;
		output_f << "\t";
		output_f << entries[i].index_2;
		output_f << "\t";
		output_f << entries[i].starting_pos;
		output_f << "\t";
		output_f << entries[i].starting_pos+entries[i].length;
		output_f << "\t";
		output_f << entries[i].length;
		output_f << "\n";

	}
	output_f.close();
}



static void show_usage(std::string name)
{
	std::cerr << "Random Projection-based IBD Detection (RaPID). Trial Version v.1.2.3\n";

	std::cerr << "RaPID is free for academic use. For commercial use, please contact authors.\n";
	std::cerr << "Usage: " << name << " <option(s)>\n"

			<< "Options:\n"
			<< "\t-h,--help                          Show this help message\n"
			<< "\t-i,--input <INPUT FILE>            Input file path in MACS format\n"
			<< "\t-o,--output <OUTPUT FOLDER>        Output folder. The final result will be results.max in the output folder\n"

			<< "\t-a,--no-allele-frequency           Ignore MAFs. By default the sites are selected at random weighted by their MAFs.\n"

			<< "\t-w,--window <WINDOW SIZE>          Window size for sub-sampling\n"
			<< "\t-r,--run <NUMBER OF RUNS>          Number of runs\n"
			<< "\t-s,--support <NUMBER OF SUCCESSES> Minimum number of successes to consider a hit\n"
			<< "\t-m,--minimum <MINIMUM IBD LENGTH>  Minimum IBD length in terms of SNPs\n"
			<< "\t-l,--length <MINIMUM IBD LENGTH>   Minimum IBD length in cM (1cM ~ Mbps)\n"
			<< "\t-t,--total <TOTAL LENGTH>          Length of chromosome in cM or Mbps\n"

			<< "\t-d,--distance <GENETIC LENGTH>     Actual Minimum IBD length in cM\n"

			<< "\t-c,--count-sites                   Count the number of sites line by line. Useful if the MaCS file is not well formatted.\n"
			<< "\t-p,--percentage-sites              Percentage of the variant sites to cover a given minimum length (m = p*N*l/t). Not applicable if the minimum length is given in terms of the number of sites(default 0.9)\n"
			<< "\t-g,--genetic_map <GENEIC MAP FILE> Genetic mapping file (each line contains #SITE and genetic_location).\n"
			<< "Required:\n"
			<< "<INPUT FILE> <OUTPUT FOLDER> <WINDOW SIZE> <NUMBER OF RUNS> <NUMBER OF SUCCESSES> <MINIMUM IBD LENGTH>  \n"
			<< "<TOTAL LENGTH> required if minimum IBD length is given in cM or Mbps \n"


			<< std::endl;
}




static int get_total_SNPS(string macs_file){

	std::ifstream read(macs_file, std::ios_base::ate );//open file
	std::string tmp;
	int length = 0;
	int counter = 0;
	char c = '\0';
	int total_sites = 0;
	if(read)
	{
		length = read.tellg();//Get file size

		for(int i = length-2; i > 0; i-- )
		{
			read.seekg(i);

			c = read.get();
			if( c == '\r' || c == '\n' )
				counter = counter + 1;
			if (counter > 3){
				break;
			}
		}

		std::getline(read, tmp);//read last line
		std::vector<std::string> strs;
		strs = split(tmp,'\t');
		total_sites = atoi(strs[1].c_str());

	}
	read.close();
	return total_sites;
}



int main(int argc, char* argv[]){


	char* genetic_filepath;
	if (argc < 3) {
		show_usage(argv[0]);
		return 1;
	}
	bool count_sites = false;
	bool maf = true;
	string input_macs;
	string output_folder;
	int window_size = 0;
	int num_runs = 0;
	string pbwt_path;
	int min_support = 0 ;
	int min_length_snps = 0;
	double minimum_length_cm = 0.0;
	int num_sites;
	double total_length = 0;
	double percentage_sites = 0.9;
	double minimum_genetic_length = 1;
	bool g_map_set = false;

	int max_num_hits = 5000000;

	for (int i = 1; i < argc; ++i) {
		std::string arg = argv[i];
		if ((arg == "-h") || (arg == "--help")) {
			show_usage(argv[0]);
			return 0;
		} else if ((arg == "-i") || (arg == "--input")) {
			if (i + 1 < argc) {
				input_macs = argv[++i];
			}
		}
		else if ((arg == "-o") || (arg == "--output")) {
			if (i + 1 < argc) {
				output_folder = argv[++i];
			}
		}
		else if ((arg == "-w") || (arg == "--window")) {
			if (i + 1 < argc) {
				window_size = atoi(argv[++i]);
			}
		}
		else if ((arg == "-r") || (arg == "--run")) {
			if (i + 1 < argc) {
				num_runs = atoi(argv[++i]);
			}
		}
		else if ((arg == "-s") || (arg == "--support")) {
			if (i + 1 < argc) {
				min_support = atoi(argv[++i]);
			}
		}
		else if ((arg == "-m") || (arg == "--minimum")) {
			if (i + 1 < argc) {
				min_length_snps = atoi(argv[++i]);
			}
		}
		else if ((arg == "-l") || (arg == "--length")) {
			if (i + 1 < argc) {
				minimum_length_cm = atof(argv[++i]);
			}
		}

		else if ((arg == "-d") || (arg == "--distance")) {
			if (i + 1 < argc) {
				minimum_genetic_length = atof(argv[++i]);
			}
		}

		else if ((arg == "-c") || (arg == "count-sites")) {
			count_sites = true;
		}

		else if ((arg == "-t") || (arg == "--total")) {
			if (i + 1 < argc) {
				total_length = atof(argv[++i]);

			}
		}else if ((arg == "-a") || (arg == "--no-allele-frequency")) {
			maf = false;
		}

		else if ((arg == "-p") || (arg == "--percentage-sites")) {
			if (i + 1 < argc) {
				percentage_sites = atof(argv[++i]);

			}
		}

		else if ((arg == "-g") || (arg == "--genetic_map")) {
			if (i + 1 < argc) {
				genetic_filepath = argv[++i];
				g_map_set = true;
			}
		}

	};

	if (input_macs == "" || output_folder == "" || window_size == 0 || num_runs <= 0 || min_support <= 0){
		show_usage(argv[0]);
		return 0;
	}

	if ((minimum_length_cm <= 0 || total_length <= 0 ) && min_length_snps <= 0){
		show_usage(argv[0]);
		return 0;
	}


	cout << "Create sub-samples..\n";
	int pop_size;


	num_sites = 0;
	if (count_sites== false){
		num_sites = get_total_SNPS(input_macs);
	}
	else{
		get_n_sites_slow(input_macs,num_sites);
	}

	double* gen_loci = new double[num_sites];
	ifstream file_g(genetic_filepath);
	string line;
	while (getline(file_g,line)){
		vector<string> vals;
		tokenize_string(line,vals,"\t ");
		gen_loci[atoi(vals[0].c_str())] =atof(vals[1].c_str());
	}
	file_g.close();



	if (minimum_length_cm > 0 and total_length > 0){
		min_length_snps = round(percentage_sites* num_sites * (minimum_length_cm/total_length));
	}
	int total_snps = 0;

	if (maf == false)
		total_snps = generate_subsamples(input_macs,window_size,num_runs,output_folder,pop_size,num_sites);
	else{
		total_snps = generate_subsamples_maf(input_macs,window_size,num_runs,output_folder,pop_size,num_sites);

	}

	cout << "Done!\n";
	cout << "Minimum length in terms of SNPs: "<< min_length_snps << "\n";

	vector<string> output_files;

	Merge merge;

	for (int i = 0; i < num_runs; i++){

		ostringstream oss;
		oss << output_folder;
		oss << "/";
		oss << "macs_subsample_";
		oss << i;

		string subsample_path = oss.str();

		ostringstream oss2;
		oss2 << output_folder;
		oss2 << "/";
		oss2 << "macs_subsample_";
		oss2 << i;
		oss2 << ".max";
		string r_pbwt_output = oss2.str();

		string output_file = oss2.str();

		if (g_map_set)
			run_PBWT(subsample_path,pbwt_path,min_length_snps/window_size,minimum_genetic_length,gen_loci,window_size,output_folder);

		else{
			run_PBWT(subsample_path,pbwt_path,min_length_snps/window_size,output_folder);
		}

		std::remove(subsample_path.c_str());

		int num_files = 0;

		merge.sort_store_compressed(output_folder,output_file,pop_size,max_num_hits,num_files);
		vector<string> output_files_each;

		for (int i = 0 ; i <num_files; i ++){
			stringstream s;
			s << output_folder;
			s << "/";
			s << i;
			output_files_each.push_back(s.str());
		}

		stringstream s;

		s << output_folder;
		s << "/" << i  <<"_";
		s << "results_sorted.max.gz";
		merge.merge_files(output_files_each,s.str(),window_size);
		output_files.push_back(s.str());


		float progress = i/ (float(num_runs));
		std::cout  << int(progress * 100.0) << " %\r";
		std::cout.flush();
	}


	stringstream s_final_output;
	s_final_output << output_folder << "/results.max.gz";
	merge.merge_files_support(output_files, s_final_output.str().c_str(),min_support);
	std::cout  << 100 << " %\r";
	std::cout.flush();


	delete[] gen_loci;
	return 0;
}
