/* Random Projection-based IBD Detection (RaPID)
 * Authors: Ardalan Naseri, Xiaoming Liu, Shaojie Zhang and Degui Zhi
 *
 *  RaPID is free for academic use. For commercial use, please contact authors.
 *  RaPID is based on Richard Durbin's PBWT (richarddurbin/pbwt).
 *
 *-------------------------------------------------------------------
 * PBWTEntry.h
 * PBWT structure to store and compare hits while merging multiple PBWT runs.
 * Created on: Oct 18, 2016
 */

using namespace std;
#include <iostream>
#include <fstream>
#include <sstream>

struct PBWT_ENTRY
{
	int index_1;
	int index_2;
	int starting_pos;
	int length;
	int ending_position;

	PBWT_ENTRY(){
		index_1 = 0;
		index_2 = 0;
		starting_pos =0;
		length =0;
		ending_position =0;
	}

	PBWT_ENTRY(int _index1, int _index2,int _starting_pos,int _length)
	{
		index_1 = _index1;
		index_2 = _index2;
		starting_pos = _starting_pos;
		length = _length;
		ending_position = starting_pos + length -1;
	}

};

std::vector<std::string> split(std::string _str, char delimeter)
																																																{
	std::stringstream ss(_str);
	std::string item;
	std::vector<std::string> splitted_strings;
	while (std::getline(ss, item, delimeter))
	{
		splitted_strings.push_back(item);
	}
	return splitted_strings;

}


PBWT_ENTRY get_PBWT_ENTRY_object(string _line)
{
	std::vector<std::string> strs;

	strs = split(_line,'\t');

	PBWT_ENTRY pbwt_entry;
	int f_index = atoi(strs[1].c_str());
	int s_index = atoi(strs[2].c_str());
	if (f_index < s_index){
		pbwt_entry.index_1 = f_index;
		pbwt_entry.index_2 = s_index;
	}
	else{
		pbwt_entry.index_1 = s_index;
		pbwt_entry.index_2 = f_index;

	}
	pbwt_entry.starting_pos = atoi(strs[3].c_str());
	pbwt_entry.length = atoi(strs[5].c_str());

	pbwt_entry.ending_position = pbwt_entry.starting_pos + pbwt_entry.length -1;

	return pbwt_entry;
}


bool cmp(const PBWT_ENTRY& lhs, const PBWT_ENTRY& rhs)
{
	if (lhs.index_1 < rhs.index_1 or lhs.index_1 > rhs.index_1){
		return lhs.index_1 < rhs.index_1;
	}
	else if (lhs.index_1 == rhs.index_1){
		return lhs.index_2 < rhs.index_2;
	}
}


bool cmpByStartingPos(const PBWT_ENTRY& lhs,const PBWT_ENTRY& rhs)
{
	return lhs.starting_pos < rhs.starting_pos;
}

bool cmpByEndingPos(const PBWT_ENTRY& lhs,const PBWT_ENTRY& rhs)
{
	return lhs.starting_pos+lhs.length < rhs.starting_pos+rhs.length;
}

bool cmpByLength(const PBWT_ENTRY& lhs,const PBWT_ENTRY& rhs)
{
	return lhs.length < rhs.length;
}
