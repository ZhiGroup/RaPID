/* Random Projection-based IBD Detection (RaPID)
 * Authors: Ardalan Naseri, Xiaoming Liu, Shaojie Zhang and Degui Zhi
 *
 *  RaPID is free for academic use. For commercial use, please contact authors.
 *  RaPID is based on Richard Durbin's PBWT (richarddurbin/pbwt).
 *
 *
 *-------------------------------------------------------------------
 * Merge.h
 * Created on: Dec 10, 2017
 */


#ifndef MERGE_H_
#define MERGE_H_

#include <vector>
#include <algorithm>
#include "utilities.h"
#include <zlib.h>
#include <fstream>
#include <algorithm>
#include <string>       // std::string
#include <iostream>     // std::cout
#include <sstream>      // std::stringstream
#include <fstream>
#include <boost/iostreams/copy.hpp>
#include <boost/iostreams/filter/gzip.hpp>
#include <boost/iostreams/filtering_streambuf.hpp>
#include "IntervalTree.h"
using namespace std;



class Merge {
public:


	Merge();
	virtual ~Merge();
	struct PBWT_ENTRY
	{
		int index_1;
		int index_2;
		int starting_pos;
		int length;
		int ending_position;

		PBWT_ENTRY(){
			index_1 = 0;
			index_2 = 0;
			starting_pos =0;
			length =0;
			ending_position =0;
		}

		PBWT_ENTRY(int _index1, int _index2,int _starting_pos,int _length)
		{
			index_1 = _index1;
			index_2 = _index2;
			starting_pos = _starting_pos;
			length = _length;
			ending_position = starting_pos + length -1;
		}

	};


	static bool cmpByStartingPos(const PBWT_ENTRY& lhs,const PBWT_ENTRY& rhs)
	{
		return lhs.starting_pos < rhs.starting_pos;
	};

	PBWT_ENTRY get_PBWT_ENTRY_object(string _line)
	{
		std::vector<std::string> strs;

		tokenize_string(_line,strs,"\t");

		PBWT_ENTRY pbwt_entry;
		int f_index = atoi(strs[1].c_str());
		int s_index = atoi(strs[2].c_str());
		if (f_index < s_index){
			pbwt_entry.index_1 = f_index;
			pbwt_entry.index_2 = s_index;
		}
		else{
			pbwt_entry.index_1 = s_index;
			pbwt_entry.index_2 = f_index;

		}
		pbwt_entry.starting_pos = atoi(strs[3].c_str());
		pbwt_entry.ending_position = atoi(strs[4].c_str());

		return pbwt_entry;
	}


	static bool cmp(const PBWT_ENTRY& lhs, const PBWT_ENTRY& rhs)
	{
		if (lhs.index_1 < rhs.index_1 or lhs.index_1 > rhs.index_1){
			return lhs.index_1 < rhs.index_1;
		}
		else if (lhs.index_1 == rhs.index_1){
			return lhs.index_2 < rhs.index_2;
		}
	}


	vector<PBWT_ENTRY> mergeIntervals(vector<PBWT_ENTRY> & hits);
	void sort_store_compressed(string output_folder,string file_path,int pop_size,int max_num_hits, int &num_files);
	vector<Merge::PBWT_ENTRY> counting_sort_first_index(vector<Merge::PBWT_ENTRY> & entries,int max_number,int entries_length);
	vector<Merge::PBWT_ENTRY> counting_sort_second_index(vector<Merge::PBWT_ENTRY> & entries,int max_number);
	void write_PBWT_entry(vector<PBWT_ENTRY> & entries,int length,string output_file);
	void merge_files_support(vector<string> file_names,string output_file,int min_support,vector<int> & genomic_loci,vector<string> &samples);
	void merge_files(vector<string> file_names,string output_file,int win_size);
	void merge_files_support(vector<string> file_names,string output_file,int min_support);

};

#endif /* MERGE_H_ */
